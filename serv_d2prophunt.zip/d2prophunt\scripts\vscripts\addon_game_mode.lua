-- Your game mode should be instantiated here
HideAndSeekGameMode:InitGameMode()